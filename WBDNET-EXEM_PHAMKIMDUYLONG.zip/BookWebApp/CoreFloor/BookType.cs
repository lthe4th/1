﻿namespace CoreFloor
{
    public enum BookType
    {
        Myth,
        ChickenSoupForSoul,
        Novel,
        LightNovel,
        History,
    }
}
