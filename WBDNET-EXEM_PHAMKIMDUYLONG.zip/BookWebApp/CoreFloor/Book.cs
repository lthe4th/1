﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace CoreFloor
{

    public class Book
    {
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required,StringLength(255)]
        public string Description { get; set; }
        [Required,]
        public int Year { get; set; }
        [Required]
        public int InStock { get; set; }
        [Required]
        public BookType BookType { get; set; }

    }
}
