﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreFloor;
using DataFloor;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookWebApp.Pages.Books
{
    public class DetailModel : PageModel
    {
        private readonly IDATA data;
        public Book Book { get; set; }
        public DetailModel(IDATA data)
        {
            this.data = data;
        }

        public void OnGet(int id)
        {
            Book = data.GetByid(id);
        }
    }
}