﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreFloor;
using DataFloor;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BookWebApp.Pages.Books
{
    public class ListModel : PageModel
    {
        private readonly IDATA data;

        [BindProperty]
        public string KeyWord { get; set; }
        public IEnumerable<Book> books { get; set; }

        public ListModel(IDATA data)
        {
            this.data = data;
        }

        public void OnGet()
        {
            books = data.GetByName(KeyWord);
        }

        public IActionResult OnPostDelete(int id)
        {
            data.DeleteBtId(id);
            return RedirectToPage("./List");

        }
    }
}