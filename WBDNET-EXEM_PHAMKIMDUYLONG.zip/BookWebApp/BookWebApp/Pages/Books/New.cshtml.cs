﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CoreFloor;
using DataFloor;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace BookWebApp.Pages.Books
{
    public class NewModel : PageModel
    {
        private readonly IHtmlHelper helper;
        private readonly IDATA data;


        [BindProperty]
        public Book Book { get; set; }
        public IEnumerable<SelectListItem> Type { get; set; }

        public NewModel(IHtmlHelper helper, IDATA data)
        {
            this.helper = helper;
            this.data = data;
        }


        public void OnGet()
        {
            Type = helper.GetEnumSelectList<BookType>();
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                Type = helper.GetEnumSelectList<BookType>();
                return Page();
            }
            if (Book != null) { 
                data.Add(Book);
            }
            return RedirectToPage("./List");
        }
    }
}