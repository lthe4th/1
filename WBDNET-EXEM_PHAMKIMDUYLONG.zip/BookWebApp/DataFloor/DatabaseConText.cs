﻿using CoreFloor;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataFloor
{
    public class DatabaseConText : DbContext
    {

        public DatabaseConText(DbContextOptions<DatabaseConText> options) : base(options)
        {

        }
        public DbSet<Book> Books { get; set; }
        
    }
}
