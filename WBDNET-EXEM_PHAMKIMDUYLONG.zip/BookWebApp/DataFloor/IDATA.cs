﻿using CoreFloor;
using System;
using System.Collections.Generic;
using System.Text;

namespace DataFloor
{
   public  interface IDATA
    {
        IEnumerable<Book> GetByName(string name);
        Book GetByid(int id);
        void DeleteBtId(int id);
        void Commit();
        void Add(Book book2Add);
       
    }
}
