﻿using System;
using System.Collections.Generic;
using System.Text;
using CoreFloor;
using System.Linq;

namespace DataFloor
{
    public class DataMethod : IDATA
    {
        private readonly DatabaseConText data;

        public DataMethod(DatabaseConText data)
        {
            this.data = data;
        }

        public void Add(Book book2Add)
        {

            data.Books.Add(book2Add);


            Commit();
        }

        public void Commit()
        {
            data.SaveChanges();
        }

        public void DeleteBtId(int id)
        {
            var book = GetByid(id);
            if (book != null)
            {
                data.Remove(book);
                Commit();
            }
        }

        public Book GetByid(int id)
        {
            return data.Books.SingleOrDefault(book => book.ID == id);
        }

        public IEnumerable<Book> GetByName(string name = null)
        {
            var result = from book in data.Books
                   where string.IsNullOrEmpty(name) || book.Name.ToLower().Contains(name.ToLower())
                   orderby book.Name
                   select book;

            return result;

        }
    }
}
